@javax.xml.bind.annotation.XmlSchema(namespace = "http://servicio.sga.gm.com.mx/")
package clientews.servicio;
