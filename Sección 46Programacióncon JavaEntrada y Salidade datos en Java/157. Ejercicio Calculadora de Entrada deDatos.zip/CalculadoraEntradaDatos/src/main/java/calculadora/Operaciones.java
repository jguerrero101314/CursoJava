package calculadora;

public class Operaciones {
    public static int sumar(int a, int b){
        return a + b;
    }
}
