package test;

import static utileria.Archivo.*; 
        
public class ManejoArchivos {
    public static void main(String[] args) {
        String nombreArchivo = "c:\\pruebaJava\\archivoPruebaJava.txt";
        
        //creamos un archivo
        crearArchivo(nombreArchivo);
        
    }
}
