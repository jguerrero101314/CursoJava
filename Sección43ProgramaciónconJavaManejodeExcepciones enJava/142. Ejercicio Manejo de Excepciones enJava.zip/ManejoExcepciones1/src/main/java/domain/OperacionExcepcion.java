package domain;

public class OperacionExcepcion extends Exception {

    public OperacionExcepcion(String mensaje) {
        super(mensaje);
    }
}
