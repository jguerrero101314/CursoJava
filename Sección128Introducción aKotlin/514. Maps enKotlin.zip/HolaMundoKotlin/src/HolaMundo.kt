fun main(args: Array<String>){
   var traduccion = mutableMapOf("hola" to "hello", "adios" to "goodbye")
   traduccion["hola"] = "Hello"
   println(traduccion["hola"])
}