fun main(args: Array<String>){
    var nombres = mutableListOf("Juan","Karla","Arturo","Luisa")
    nombres.add("Gerardo")
    println(nombres.size)
    println(nombres[0])

    for (nombre in nombres){
        println(nombre)
    }

    for(x in 5..8){
        println(x)
    }
}