fun main(args: Array<String>){
    var nombres = mutableListOf("Juan","Karla","Arturo","Luisa")
    nombres.add("Gerardo")
    println(nombres.size)
    println(nombres[0])
}