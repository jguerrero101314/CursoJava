fun main(args: Array<String>){
    println("Hola Mundo desde Kotlin")

   var nombre = "Juan"

   var apellido = "Lara"

    println(nombre + " " + apellido)

    var comentario = """
    Mi nombre es
    $nombre
    Mi apellido es
    $apellido    
    """

    println(comentario)
}