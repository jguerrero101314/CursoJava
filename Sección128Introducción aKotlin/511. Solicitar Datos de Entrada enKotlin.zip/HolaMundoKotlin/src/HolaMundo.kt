fun main(args: Array<String>){
    println("Proporciona el nombre")
    var nombre = readLine()
    println("El nombre es $nombre")

    println("Proporciona el apellido")
    var apellido = readLine()
    println("El apellido es $apellido")

}