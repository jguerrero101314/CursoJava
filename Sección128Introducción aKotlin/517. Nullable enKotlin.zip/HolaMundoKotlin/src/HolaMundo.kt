fun main(args: Array<String>){
    var nombre: String? = "Juan"
    nombre = null
    println(nombre)

    nombre = "Juan"
    println(nombre)

    var edad: Int? = 30
    edad = null
    println(edad)
}