fun main(args: Array<String>){
    println("Hola Mundo desde Kotlin")

    var edad = 28
    println(edad)

    edad = 35
    println(edad)

    val nombre = "Juan"
    println(nombre)

    //nombre = "Carlos"
    /*
    comentarios
     */

    val apellido:String
    apellido = "Lara"
    //apellido = "Esparaza"
    println(apellido)
}