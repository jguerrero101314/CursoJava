fun main(args: Array<String>){

    fun saludar(){
        println("Saludos desde mi funcion")
    }

    saludar()

//    fun despedir(nombre: String = "Juan", apellido: String):String {
//        return "Hasta luego $nombre $apellido"
//    }

    fun despedir(nombre: String, apellido: String) =  "Hasta luego $nombre $apellido"

    println(despedir("Karla","Juarez"))

}