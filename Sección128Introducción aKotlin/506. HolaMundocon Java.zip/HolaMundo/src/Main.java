public class Main {
    public static void main(String[] args) {
        //este es un comentario
        /*
        este es un comentario
        de multiples lineas
         */
        System.out.println("Hola Mundo");
        System.out.println("Adios");
    }
}
