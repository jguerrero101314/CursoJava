fun main(args: Array<String>){

    class Persona{
        var nombre: String
        var apellido: String

        constructor(){
            this.nombre = "Karla"
            this.apellido = "Juarez"
        }

//        init {
//            this.nombre = "Karla"
//            this.apellido = "Juarez"
//        }

        fun imprimirAtributos(){
            println("nombre: ${this.nombre}, apellido: ${this.apellido}" )
        }
    }

    var persona = Persona()
//    persona.nombre = "Carlos"

    println(persona.imprimirAtributos())

}