package test;

import bloquescodigo.Persona;

public class BloquesCodigo {
    public static void main(String[] args) {
        Persona p1 = new Persona();
        int idPersona = p1.getIdPersona();
        System.out.println("idPersona = " + idPersona);
    }
}
